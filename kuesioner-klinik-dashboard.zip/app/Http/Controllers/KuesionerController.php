<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Dokter;
use App\Models\Perawat;
use App\Models\Kuesioner;
use App\Models\KuesionerKlinik;
use App\Models\KuesionerDokter;
use App\Models\KuesionerPerawat;

class KuesionerController extends Controller
{
    // ─── Step 1: Identitas ───────────────────────────────────────────
    public function index()
    {
        session()->forget(['identitas', 'klinik', 'dokter', 'perawat', 'komplain']);
        return view('kuesioner.step1-identitas');
    }

    public function storeIdentitas(Request $request)
    {
        $data = $request->validate([
            'nama'    => 'required|string|max:255',
            'no_telp' => 'required|string|max:20',
        ]);

        session(['identitas' => $data]);
        return redirect()->route('kuesioner.klinik');
    }

    // ─── Step 2: Klinik ───────────────────────────────────────────────
    public function klinik()
    {
        if (!session('identitas')) return redirect()->route('kuesioner.index');
        return view('kuesioner.step2-klinik');
    }

    public function storeKlinik(Request $request)
    {
        $rules = [];
        for ($i = 1; $i <= 15; $i++) {
            $rules["q{$i}"] = 'required|integer|between:1,5';
        }
        $data = $request->validate($rules);
        session(['klinik' => $data]);
        return redirect()->route('kuesioner.dokter');
    }

    // ─── Step 3: Dokter ───────────────────────────────────────────────
    public function dokter()
    {
        if (!session('klinik')) return redirect()->route('kuesioner.klinik');
        return view('kuesioner.step3-dokter', [
            'dokter' => Dokter::orderBy('nama')->get(),
        ]);
    }

    public function storeDokter(Request $request)
    {
        $rules = ['nama_dokter' => 'required|exists:dokters,id'];
        for ($i = 1; $i <= 15; $i++) {
            $rules["q{$i}"] = 'required|integer|between:1,5';
        }
        $data = $request->validate($rules);
        $data['kritik_saran'] = $request->kritik_saran;
        session(['dokter' => $data]);
        return redirect()->route('kuesioner.perawat');
    }

    // ─── Step 4: Perawat ──────────────────────────────────────────────
    public function perawat()
    {
        if (!session('dokter')) return redirect()->route('kuesioner.dokter');
        return view('kuesioner.step4-perawat', [
            'perawat' => Perawat::orderBy('nama')->get(),
        ]);
    }

    public function storePerawat(Request $request)
    {
        $rules = ['nama_perawat' => 'required|exists:perawats,id'];
        for ($i = 1; $i <= 15; $i++) {
            $rules["q{$i}"] = 'required|integer|between:1,5';
        }
        $data = $request->validate($rules);
        $data['kritik_saran'] = $request->kritik_saran;
        session(['perawat' => $data]);
        return redirect()->route('kuesioner.komplain');
    }

    // ─── Step 5: Komplain ─────────────────────────────────────────────
    public function komplain()
    {
        if (!session('perawat')) return redirect()->route('kuesioner.perawat');
        return view('kuesioner.step5-komplain');
    }

    public function storeKomplain(Request $request)
    {
        $data = $request->validate([
            'has_complain' => 'nullable|in:0,1',
            'komplain'     => 'nullable|string|max:2000',
        ]);

        session(['komplain' => $data]);

        // ── Save all data to DB ──────────────────────────────────────
        $identitas = session('identitas');
        $klinik    = session('klinik');
        $dokter    = session('dokter');
        $perawat   = session('perawat');

        $kuesioner = Kuesioner::create([
            'nama'         => $identitas['nama'],
            'no_telp'      => $identitas['no_telp'],
            'has_complain' => $data['has_complain'] ?? null,
            'komplain'     => ($data['has_complain'] == '1') ? ($data['komplain'] ?? null) : null,
        ]);

        // Klinik ratings
        $klinikData = ['kuesioner_id' => $kuesioner->id];
        for ($i = 1; $i <= 15; $i++) {
            $klinikData["q{$i}"] = $klinik["q{$i}"];
        }
        KuesionerKlinik::create($klinikData);

        // Dokter ratings
        $dokterData = [
            'kuesioner_id' => $kuesioner->id,
            'dokter_id'    => $dokter['nama_dokter'],
            'kritik_saran' => $dokter['kritik_saran'] ?? null,
        ];
        for ($i = 1; $i <= 15; $i++) {
            $dokterData["q{$i}"] = $dokter["q{$i}"];
        }
        KuesionerDokter::create($dokterData);

        // Perawat ratings
        $perawatData = [
            'kuesioner_id' => $kuesioner->id,
            'perawat_id'   => $perawat['nama_perawat'],
            'kritik_saran' => $perawat['kritik_saran'] ?? null,
        ];
        for ($i = 1; $i <= 15; $i++) {
            $perawatData["q{$i}"] = $perawat["q{$i}"];
        }
        KuesionerPerawat::create($perawatData);

        session()->forget(['identitas', 'klinik', 'dokter', 'perawat', 'komplain']);

        return redirect()->route('kuesioner.thankyou');
    }

    // ─── Step 6: Thank You ────────────────────────────────────────────
    public function thankyou()
    {
        return view('kuesioner.step6-thankyou');
    }
}
