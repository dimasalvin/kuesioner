<?php
// app/Http/Controllers/Dashboard/ManagementController.php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\{Kuesioner, Dokter, Perawat};
use Illuminate\Http\Request;

class ManagementController extends Controller
{
    public function index()
    {
        return view('dashboard.management.index', [
            'stats'        => [
                'total_kuesioner' => Kuesioner::count(),
                'total_komplain'  => Kuesioner::whereHasComplain()->count(),
                'total_dokter'    => Dokter::count(),
                'total_perawat'   => Perawat::count(),
            ],
            'chartKlinik'  => AdminController::chartData('klinik'),
            'chartDokter'  => AdminController::chartData('dokter'),
            'chartPerawat' => AdminController::chartData('perawat'),
            'ratingDokter' => $this->topRatings('dokter'),
            'ratingPerawat'=> $this->topRatings('perawat'),
        ]);
    }

    public function komplain(Request $request)
    {
        $komplain = Kuesioner::whereHasComplain()
            ->when($request->search, fn($q,$s) =>
                $q->where('nama','like',"%$s%")->orWhere('komplain','like',"%$s%"))
            ->latest()->paginate(20)->withQueryString();

        return view('dashboard.management.komplain', compact('komplain'));
    }

    public function chartApi(string $type)
    {
        return response()->json(AdminController::chartData($type));
    }

    private function topRatings(string $type): \Illuminate\Support\Collection
    {
        if ($type === 'dokter') {
            return \DB::table('kuesioner_dokters as kd')
                ->join('dokters as d', 'd.id', '=', 'kd.dokter_id')
                ->selectRaw('d.nama, d.spesialisasi, COUNT(kd.id) as total,
                    ROUND(AVG((kd.q1+kd.q2+kd.q3+kd.q4+kd.q5+kd.q6+kd.q7+kd.q8+kd.q9+kd.q10+kd.q11+kd.q12+kd.q13+kd.q14+kd.q15)/15.0),2) as rata_rata')
                ->groupBy('d.id','d.nama','d.spesialisasi')
                ->orderByDesc('rata_rata')
                ->limit(5)->get();
        }

        return \DB::table('kuesioner_perawats as kp')
            ->join('perawats as p', 'p.id', '=', 'kp.perawat_id')
            ->selectRaw('p.nama, COUNT(kp.id) as total,
                ROUND(AVG((kp.q1+kp.q2+kp.q3+kp.q4+kp.q5+kp.q6+kp.q7+kp.q8+kp.q9+kp.q10+kp.q11+kp.q12+kp.q13+kp.q14+kp.q15)/15.0),2) as rata_rata')
            ->groupBy('p.id','p.nama')
            ->orderByDesc('rata_rata')
            ->limit(5)->get();
    }
}
