@extends('layouts.app')
@section('title', 'Kuesioner Perawat')

@section('content')
<div class="step-header">
    <div class="step-progress" data-current="4" data-total="6"></div>
    <div class="page-title">Kuesioner Perawat</div>
    <div class="page-subtitle">Langkah 4 dari 6 — Penilaian Perawat</div>
</div>

<form id="kuesioner-form" method="POST" action="{{ route('kuesioner.store-perawat') }}">
    @csrf

    <div class="scroll-content">
        @if($errors->any())
            <div class="alert-box">Mohon pilih nama perawat dan lengkapi semua penilaian.</div>
        @endif

        <!-- Select Perawat -->
        <div class="field-group">
            <label class="field-label" for="nama_perawat">Nama Perawat</label>
            <div class="select-wrapper">
                <select id="nama_perawat" name="nama_perawat" class="field-input" required>
                    <option value="" disabled {{ !session('perawat.nama_perawat') ? 'selected' : '' }}>Pilih nama perawat...</option>
                    @foreach($perawat as $p)
                        <option value="{{ $p->id }}" {{ session('perawat.nama_perawat') == $p->id ? 'selected' : '' }}>
                            {{ $p->nama }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="field-error" style="{{ $errors->has('nama_perawat') ? '' : 'display:none' }}">
                Pilih salah satu perawat.
            </div>
        </div>

        <div class="section-divider"><span>Penilaian</span></div>

        <div class="q-list">
            @php
            $pertanyaan = [
                1  => 'Apakah Nakes informatif dalam menjelaskan prosedur?',
                2  => 'Apakah perawat cepat tanggap terhadap kebutuhan Anda?',
                3  => 'Apakah perawat bersikap empati?',
                4  => 'Apakah perawat melakukan tindakan dengan hati-hati?',
                5  => 'Apakah perawat menjelaskan prosedur dengan jelas?',
                6  => 'Apakah perawat menjaga kebersihan saat tindakan?',
                7  => 'Apakah perawat menghormati privasi pasien?',
                8  => 'Apakah perawat memperkenalkan diri sebelum tindakan?',
                9  => 'Apakah perawat komunikatif?',
                10 => 'Apakah perawat memberikan dukungan psikologis?',
                11 => 'Apakah perawat tepat waktu?',
                12 => 'Apakah perawat memberikan edukasi kesehatan?',
                13 => 'Apakah perawat bekerja sama dengan tim dengan baik?',
                14 => 'Apakah Anda merasa aman dengan tindakan perawat?',
                15 => 'Apakah Nakes ramah dan bersahabat?',
            ];
            @endphp

            @foreach($pertanyaan as $no => $teks)
            <div class="q-item {{ session("perawat.q{$no}") ? 'answered' : '' }}">
                <div class="q-number">Pertanyaan {{ $no }}</div>
                <div class="q-text">{{ $teks }}</div>
                <div class="star-rating" data-required>
                    @for($i = 1; $i <= 5; $i++)
                    <input type="radio" name="q{{ $no }}" id="perawat_q{{ $no }}_{{ $i }}" value="{{ $i }}"
                        {{ session("perawat.q{$no}") == $i ? 'checked' : '' }}>
                    <label for="perawat_q{{ $no }}_{{ $i }}" title="{{ $i }} bintang">★</label>
                    @endfor
                </div>
            </div>
            @endforeach
        </div>

        <div class="section-divider"><span>Masukan</span></div>

        <div class="field-group">
            <label class="field-label" for="kritik_perawat">Kritik & Saran</label>
            <textarea
                id="kritik_perawat"
                name="kritik_saran"
                class="field-input"
                placeholder="Tuliskan kritik atau saran Anda untuk perawat... (opsional)"
            >{{ session('perawat.kritik_saran') }}</textarea>
        </div>
    </div>

    <div class="bottom-cta">
        <button type="submit" class="btn-next">
            Selanjutnya
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
        </button>
    </div>
</form>
@endsection
