@extends('layouts.app')
@section('title', 'Identitas Pasien')

@section('content')
<!-- Hero Image -->
<div class="hero-block">
    <div class="hero-illustration">
        <svg viewBox="0 0 200 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            <!-- Hospital building illustration -->
            <rect x="60" y="40" width="80" height="65" fill="#2BBFA4" rx="4" opacity="0.15"/>
            <rect x="60" y="40" width="80" height="65" stroke="#2BBFA4" stroke-width="2" rx="4"/>
            <!-- Cross symbol -->
            <rect x="92" y="52" width="16" height="5" fill="#2BBFA4" rx="2"/>
            <rect x="97" y="47" width="6" height="15" fill="#2BBFA4" rx="2"/>
            <!-- Windows -->
            <rect x="72" y="60" width="14" height="14" fill="#5BA4E5" rx="2" opacity="0.5"/>
            <rect x="114" y="60" width="14" height="14" fill="#5BA4E5" rx="2" opacity="0.5"/>
            <!-- Door -->
            <rect x="88" y="80" width="24" height="25" fill="#1E9A87" rx="3" opacity="0.4"/>
            <!-- Roof accent -->
            <path d="M55 42 L100 18 L145 42" stroke="#2BBFA4" stroke-width="2" fill="none"/>
            <!-- Ground line -->
            <line x1="30" y1="105" x2="170" y2="105" stroke="#D0D8E0" stroke-width="1.5"/>
            <!-- Trees -->
            <circle cx="40" cy="95" r="12" fill="#E6F9F5" stroke="#2BBFA4" stroke-width="1.5"/>
            <line x1="40" y1="107" x2="40" y2="105" stroke="#2BBFA4" stroke-width="1.5"/>
            <circle cx="160" cy="95" r="12" fill="#E6F9F5" stroke="#2BBFA4" stroke-width="1.5"/>
            <line x1="160" y1="107" x2="160" y2="105" stroke="#2BBFA4" stroke-width="1.5"/>
        </svg>
    </div>
</div>

<!-- Step Header -->
<div class="step-header">
    <div class="step-progress" data-current="1" data-total="6"></div>
    <div class="page-title">Data Diri Anda</div>
    <div class="page-subtitle">Langkah 1 dari 6 — Identitas Pasien</div>
</div>

<form id="kuesioner-form" method="POST" action="{{ route('kuesioner.store-identitas') }}">
    @csrf

    <div class="scroll-content">
        @if($errors->any())
            <div class="alert-box">Mohon lengkapi semua field yang diperlukan.</div>
        @endif

        <div class="field-group">
            <label class="field-label" for="nama">Nama Lengkap</label>
            <input
                type="text"
                id="nama"
                name="nama"
                class="field-input"
                placeholder="Masukkan nama lengkap Anda"
                value="{{ old('nama', session('identitas.nama')) }}"
                required
                autocomplete="name"
            >
            <div class="field-error" style="{{ $errors->has('nama') ? '' : 'display:none' }}">
                Nama tidak boleh kosong.
            </div>
        </div>

        <div class="field-group">
            <label class="field-label" for="no_telp">Nomor Telepon</label>
            <input
                type="tel"
                id="no_telp"
                name="no_telp"
                class="field-input"
                placeholder="08xx-xxxx-xxxx"
                value="{{ old('no_telp', session('identitas.no_telp')) }}"
                required
                autocomplete="tel"
                inputmode="numeric"
            >
            <div class="field-error" style="{{ $errors->has('no_telp') ? '' : 'display:none' }}">
                Nomor telepon tidak boleh kosong.
            </div>
        </div>

        <p class="text-muted mt-4">
            ✦ Data Anda akan dijaga kerahasiaannya dan hanya digunakan untuk kepentingan evaluasi layanan.
        </p>
    </div>

    <div class="bottom-cta">
        <button type="submit" class="btn-next">
            Selanjutnya
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
        </button>
    </div>
</form>
@endsection
