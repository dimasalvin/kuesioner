@extends('layouts.app')
@section('title', 'Kuesioner Klinik')

@section('content')
<div class="step-header">
    <div class="step-progress" data-current="2" data-total="6"></div>
    <div class="page-title">Kuesioner Klinik</div>
    <div class="page-subtitle">Langkah 2 dari 6 — Penilaian Fasilitas</div>
</div>

<form id="kuesioner-form" method="POST" action="{{ route('kuesioner.store-klinik') }}">
    @csrf

    <div class="scroll-content">
        @if($errors->any())
            <div class="alert-box">Mohon lengkapi semua penilaian bintang.</div>
        @endif

        <div class="q-list">
            @php
            $pertanyaan = [
                1  => 'Apakah klinik bersih dan terawat?',
                2  => 'Apakah suasana ruang tunggu nyaman?',
                3  => 'Apakah fasilitas klinik memadai?',
                4  => 'Apakah area parkir tersedia dengan cukup?',
                5  => 'Apakah papan informasi/petunjuk jelas?',
                6  => 'Apakah jam operasional klinik sesuai?',
                7  => 'Apakah proses pendaftaran mudah?',
                8  => 'Apakah waktu tunggu tidak terlalu lama?',
                9  => 'Apakah sistem antrian berjalan baik?',
                10 => 'Apakah administrasi pelayanan baik?',
                11 => 'Apakah klinik mudah dijangkau?',
                12 => 'Apakah apotek klinik lengkap?',
                13 => 'Apakah biaya pelayanan sesuai?',
                14 => 'Apakah klinik menerima BPJS / asuransi?',
                15 => 'Apakah toilet bersih dan terawat?',
            ];
            @endphp

            @foreach($pertanyaan as $no => $teks)
            <div class="q-item {{ session("klinik.q{$no}") ? 'answered' : '' }}">
                <div class="q-number">Pertanyaan {{ $no }}</div>
                <div class="q-text">{{ $teks }}</div>
                <div class="star-rating" data-required>
                    @for($i = 1; $i <= 5; $i++)
                    <input type="radio" name="q{{ $no }}" id="klinik_q{{ $no }}_{{ $i }}" value="{{ $i }}"
                        {{ session("klinik.q{$no}") == $i ? 'checked' : '' }}>
                    <label for="klinik_q{{ $no }}_{{ $i }}" title="{{ $i }} bintang">★</label>
                    @endfor
                </div>
            </div>
            @endforeach
        </div>
    </div>

    <div class="bottom-cta">
        <button type="submit" class="btn-next">
            Selanjutnya
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
        </button>
    </div>
</form>
@endsection
