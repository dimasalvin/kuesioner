@extends('layouts.app')
@section('title', 'Kuesioner Dokter')

@section('content')
<div class="step-header">
    <div class="step-progress" data-current="3" data-total="6"></div>
    <div class="page-title">Kuesioner Dokter</div>
    <div class="page-subtitle">Langkah 3 dari 6 — Penilaian Dokter</div>
</div>

<form id="kuesioner-form" method="POST" action="{{ route('kuesioner.store-dokter') }}">
    @csrf

    <div class="scroll-content">
        @if($errors->any())
            <div class="alert-box">Mohon pilih nama dokter dan lengkapi semua penilaian.</div>
        @endif

        <!-- Select Dokter -->
        <div class="field-group">
            <label class="field-label" for="nama_dokter">Nama Dokter</label>
            <div class="select-wrapper">
                <select id="nama_dokter" name="nama_dokter" class="field-input" required>
                    <option value="" disabled {{ !session('dokter.nama_dokter') ? 'selected' : '' }}>Pilih nama dokter...</option>
                    @foreach($dokter as $d)
                        <option value="{{ $d->id }}" {{ session('dokter.nama_dokter') == $d->id ? 'selected' : '' }}>
                            {{ $d->nama }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="field-error" style="{{ $errors->has('nama_dokter') ? '' : 'display:none' }}">
                Pilih salah satu dokter.
            </div>
        </div>

        <div class="section-divider"><span>Penilaian</span></div>

        <div class="q-list">
            @php
            $pertanyaan = [
                1  => 'Apakah Nakes informatif dalam menjelaskan penyakit?',
                2  => 'Apakah dokter mendengarkan keluhan Anda dengan baik?',
                3  => 'Apakah dokter memeriksa dengan teliti?',
                4  => 'Apakah dokter memberikan diagnosis yang jelas?',
                5  => 'Apakah penjelasan resep obat mudah dipahami?',
                6  => 'Apakah dokter bersikap profesional?',
                7  => 'Apakah dokter menghormati privasi pasien?',
                8  => 'Apakah dokter tersedia sesuai jadwal?',
                9  => 'Apakah waktu konsultasi cukup?',
                10 => 'Apakah dokter memberikan saran gaya hidup?',
                11 => 'Apakah Anda puas dengan tindakan medis?',
                12 => 'Apakah dokter memberikan informed consent?',
                13 => 'Apakah dokter mudah dihubungi jika ada pertanyaan?',
                14 => 'Apakah dokter bekerja sama dengan tenaga lain dengan baik?',
                15 => 'Apakah Nakes ramah dan bersahabat?',
            ];
            @endphp

            @foreach($pertanyaan as $no => $teks)
            <div class="q-item {{ session("dokter.q{$no}") ? 'answered' : '' }}">
                <div class="q-number">Pertanyaan {{ $no }}</div>
                <div class="q-text">{{ $teks }}</div>
                <div class="star-rating" data-required>
                    @for($i = 1; $i <= 5; $i++)
                    <input type="radio" name="q{{ $no }}" id="dokter_q{{ $no }}_{{ $i }}" value="{{ $i }}"
                        {{ session("dokter.q{$no}") == $i ? 'checked' : '' }}>
                    <label for="dokter_q{{ $no }}_{{ $i }}" title="{{ $i }} bintang">★</label>
                    @endfor
                </div>
            </div>
            @endforeach
        </div>

        <div class="section-divider"><span>Masukan</span></div>

        <div class="field-group">
            <label class="field-label" for="kritik_dokter">Kritik & Saran</label>
            <textarea
                id="kritik_dokter"
                name="kritik_saran"
                class="field-input"
                placeholder="Tuliskan kritik atau saran Anda untuk dokter... (opsional)"
            >{{ session('dokter.kritik_saran') }}</textarea>
        </div>
    </div>

    <div class="bottom-cta">
        <button type="submit" class="btn-next">
            Selanjutnya
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
        </button>
    </div>
</form>
@endsection
