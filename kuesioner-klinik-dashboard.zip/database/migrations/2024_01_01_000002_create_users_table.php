<?php
// database/migrations/2024_01_01_000002_create_users_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            // 'administrator' | 'management' | 'user'
            $table->enum('role', ['administrator', 'management', 'user'])->default('user');
            // null jika bukan dokter/perawat; diisi jika role = user
            $table->enum('tipe_nakes', ['dokter', 'perawat'])->nullable();
            // FK ke dokters atau perawats, tergantung tipe_nakes
            $table->unsignedBigInteger('nakes_id')->nullable();
            $table->boolean('aktif')->default(true);
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('users');
    }
};
