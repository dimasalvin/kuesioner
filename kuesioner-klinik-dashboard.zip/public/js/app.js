/* ============================================
   KUESIONER KLINIK - App JavaScript
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {

    /* ---- Star Rating Logic ---- */
    document.querySelectorAll('.star-rating').forEach(group => {
        const labels  = group.querySelectorAll('label');
        const inputs  = group.querySelectorAll('input[type="radio"]');
        const qItem   = group.closest('.q-item');

        const refreshStars = (selectedVal) => {
            labels.forEach((lbl, idx) => {
                lbl.classList.toggle('active', idx < selectedVal);
            });
            if (qItem && selectedVal > 0) qItem.classList.add('answered');
        };

        // Restore if already checked (back navigation)
        let currentVal = 0;
        inputs.forEach((inp, idx) => {
            if (inp.checked) currentVal = idx + 1;
        });
        refreshStars(currentVal);

        // Hover preview
        labels.forEach((lbl, idx) => {
            lbl.addEventListener('mouseenter', () => refreshStars(idx + 1));
            lbl.addEventListener('mouseleave', () => {
                let val = 0;
                inputs.forEach((inp, i) => { if (inp.checked) val = i + 1; });
                refreshStars(val);
            });

            // Touch / Click
            lbl.addEventListener('click', () => {
                inputs[idx].checked = true;
                refreshStars(idx + 1);
                if (qItem) qItem.classList.add('answered');
            });
        });
    });

    /* ---- Step Progress Dots ---- */
    const progressContainer = document.querySelector('.step-progress');
    if (progressContainer) {
        const currentStep = parseInt(progressContainer.dataset.current || 1);
        const totalSteps  = parseInt(progressContainer.dataset.total  || 6);
        progressContainer.innerHTML = '';
        for (let i = 1; i <= totalSteps; i++) {
            const dot = document.createElement('div');
            dot.classList.add('step-dot');
            if      (i === currentStep) dot.classList.add('active');
            else if (i <  currentStep)  dot.classList.add('done');
            progressContainer.appendChild(dot);
        }
    }

    /* ---- Complaint Toggle ---- */
    const yesBtn       = document.getElementById('btn-yes');
    const noBtn        = document.getElementById('btn-no');
    const complaintBox = document.getElementById('complaint-box');
    const hasComplain  = document.getElementById('has_complain');

    if (yesBtn && noBtn) {
        yesBtn.addEventListener('click', () => {
            yesBtn.classList.add('selected');
            noBtn.classList.remove('selected');
            if (complaintBox) complaintBox.classList.add('show');
            if (hasComplain)  hasComplain.value = '1';
        });

        noBtn.addEventListener('click', () => {
            noBtn.classList.add('selected');
            yesBtn.classList.remove('selected');
            if (complaintBox) complaintBox.classList.remove('show');
            if (hasComplain)  hasComplain.value = '0';
        });

        // Restore state
        if (hasComplain && hasComplain.value === '1') {
            yesBtn.classList.add('selected');
            if (complaintBox) complaintBox.classList.add('show');
        } else if (hasComplain && hasComplain.value === '0') {
            noBtn.classList.add('selected');
        }
    }

    /* ---- Client-Side Validation ---- */
    const form = document.getElementById('kuesioner-form');
    if (form) {
        form.addEventListener('submit', (e) => {
            let valid = true;

            // Required text inputs
            form.querySelectorAll('[required]').forEach(inp => {
                const err = inp.nextElementSibling;
                if (!inp.value.trim()) {
                    valid = false;
                    inp.style.borderColor = 'var(--coral)';
                    if (err && err.classList.contains('field-error')) {
                        err.style.display = 'block';
                    }
                } else {
                    inp.style.borderColor = '';
                    if (err && err.classList.contains('field-error')) {
                        err.style.display = 'none';
                    }
                }
            });

            // Required star groups
            form.querySelectorAll('.star-rating[data-required]').forEach(group => {
                const checked = group.querySelector('input:checked');
                const qItem   = group.closest('.q-item');
                if (!checked) {
                    valid = false;
                    if (qItem) {
                        qItem.style.borderColor = 'var(--coral)';
                        qItem.style.borderLeft  = '4px solid var(--coral)';
                    }
                }
            });

            if (!valid) {
                e.preventDefault();
                // Scroll to first error
                const firstErr = form.querySelector('[style*="coral"]');
                if (firstErr) firstErr.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });

        // Clear red borders on input
        form.querySelectorAll('input, textarea, select').forEach(inp => {
            inp.addEventListener('input', () => { inp.style.borderColor = ''; });
        });
    }

    /* ---- Smooth page load animation ---- */
    document.querySelectorAll('.q-item, .field-group, .step-header').forEach((el, i) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(16px)';
        el.style.transition = 'opacity 0.35s ease, transform 0.35s ease';
        setTimeout(() => {
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        }, 80 + i * 40);
    });
});
